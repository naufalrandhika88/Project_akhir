import { Component, OnInit } from '@angular/core';
import { NavController,ToastController } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { Newsa, NewsTestService } from '../service/news-test.service';

@Component({
  selector: 'app-add-news',
  templateUrl: './add-news.page.html',
  styleUrls: ['./add-news.page.scss'],
})
export class AddNewsPage implements OnInit {
  newsa: Newsa = {
    title: '',
    deskripsi: '',
    image: ''
  };
  constructor(
    private navCtrl: NavController,
    private activatedRoute: ActivatedRoute, 
    private ideaService: NewsTestService,
    private toastCtrl: ToastController, 
    private router: Router
    ) { }

  ngOnInit() {
    
  }
  addNewsa(){
    this.ideaService.addNewsa(this.newsa).then(() => {
      this.router.navigateByUrl('/');
      this.showToast('Idea added');
    }, err => {
      this.showToast('There was a problem adding your idea :(');
    });
  }
  
  showToast(msg){
    this.toastCtrl.create({
      message: msg,
      duration: 2000
    }).then(toast => toast.present());
  }
}
