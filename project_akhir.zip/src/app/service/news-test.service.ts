import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection, DocumentReference } from '@angular/fire/firestore';
import { map, take } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface Newsa {
  id?: string,
  title: string,
  deskripsi: string,
  image: string
}

@Injectable({
  providedIn: 'root'
})

export class NewsTestService {
  private news: Observable<Newsa[]>;
  private newsCollection: AngularFirestoreCollection<Newsa>;

  constructor(public afs: AngularFirestore) {
    this.newsCollection = this.afs.collection<Newsa>('newsa');
    this.news = this.newsCollection.snapshotChanges().pipe(
      map(actions => {
        return actions.map(a => {
          const data = a.payload.doc.data();
          const id = a.payload.doc.id;
          return { id, ...data };
        });
      })
    );
  }
  getNews(): Observable<Newsa[]> {
    return this.news;
  }

  getNew(id: string): Observable<Newsa>{
    return this.newsCollection.doc<Newsa>(id).valueChanges().pipe(
      take(1),
      map(news => {
        news.id = id;
        return news;
      })
    );
  }

  addNewsa(newsa: Newsa): Promise<DocumentReference> {
    return this.newsCollection.add(newsa);
  }

  updateIdea(newsa: Newsa): Promise<void> {
    return this.newsCollection.doc(newsa.id).update({ title: newsa.title, deskripsi: newsa.deskripsi, image: newsa.image});
  }

  deleteIdea(id: string): Promise<void> {
    return this.newsCollection.doc(id).delete();
  }
}
